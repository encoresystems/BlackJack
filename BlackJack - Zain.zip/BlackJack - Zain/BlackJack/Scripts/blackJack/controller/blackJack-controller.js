﻿blackJackApp.controller("blackJackController", ['$scope', function ($scope) {
    $scope.$root.title = 'Black Jack';
    $scope.$on('$viewContentLoaded', function () {
        $window.ga('send', 'pageview', { 'page': $location.path(), 'title': $scope.$root.title });
    });

    var _blackJack = {};
    _blackJack.cardDeckIndex = [];
    _blackJack.cardDeck = [];
    _blackJack.players = [];
    _blackJack.playerHasBlackJack = false;

    //#region CreatingCardDeck, Shuffling and DrawCard
    while (_blackJack.cardDeck.length < 52) {
        var cardPrefix;
        var cardValue;
        cardPrefix = _getCardPrefix(_blackJack.cardDeck.length);
        for (var j = 1; j <= 13; j++) {

            //getting card values
            if (j == 1) {
                cardValue = 11
            }
            else if (j >= 2 && j <= 10) {
                cardValue = j;
            }
            else if (j >= 11) {
                cardValue = 10;
            }
            // pusing the card in the card deck
            _blackJack.cardDeck.push({ card: cardPrefix + '_' + j, value: cardValue })
        }
    }

    function _getCardPrefix(cardIndex) {
        if (cardIndex <= 12) {
            return 'C';
        }
        else if (cardIndex > 12 && cardIndex <= 25) {
            return 'S';
        }
        else if (cardIndex > 25 && cardIndex <= 38) {
            return 'H';
        }
        else if (cardIndex > 38 && cardIndex <= 51) {
            return 'D';
        }
    }

    function _shuffleCards() {
        for (var i = 0; i < 52; i++) {
            _blackJack.cardDeckIndex.push(i);
        }

        var deckLength = _blackJack.cardDeckIndex.length - 1;
        var toSwap;
        var temp;
        for (var i = deckLength; i > 0; i--) {
            toSwap = Math.floor(Math.random() * i);
            temp = _blackJack.cardDeckIndex[i];
            _blackJack.cardDeckIndex[i] = _blackJack.cardDeckIndex[toSwap];
            _blackJack.cardDeckIndex[toSwap] = temp;
        }
    }

    function _drawCard() {
        var cardIndex = _blackJack.cardDeckIndex.pop();
        return _blackJack.cardDeck[cardIndex];
    }
    //#endRegion

    function _calculateAllPlayerCardSum() {
        for (var i = 0; i < _blackJack.players.length; i++) {
            for (var j = 0; j < _blackJack.players[i].cards.length; j++) {
                if (_blackJack.players[i].cards[j].value == 11) {
                    if (_blackJack.players[i].cardOldSum + 11 < 21 && _blackJack.players[i].cardSum + 11 < 21) {
                        _blackJack.players[i].cardSum = _blackJack.players[i].cardSum + 11;
                    }
                    else {
                        _blackJack.players[i].cardSum = _blackJack.players[i].cardSum + 1;
                    }
                }
                else {
                    _blackJack.players[i].cardSum = _blackJack.players[i].cardSum + parseInt(_blackJack.players[i].cards[j].value);
                }

            }
        }
    }
    function _calculatePlayerCardSum(player) {
        player.cardOldSum = player.cardSum;
        player.cardSum = 0;
        for (var j = 0; j < player.cards.length; j++) {
            if (player.cards[j].value == 11) {
                if (player.cardOldSum + 11 < 21 && player.cardSum + 11 < 21) {
                    player.cardSum = player.cardSum + 11;
                }
                else {
                    player.cardSum = player.cardSum + 1;
                }
            }
            else {
                player.cardSum = player.cardSum + parseInt(player.cards[j].value);
            }

        }
    }
    function _calculateDealerCardSum() {
        _blackJack.dealer.cardOldSum = _blackJack.dealer.cardSum;
        _blackJack.dealer.cardSum = 0;
        for (var j = 0; j < _blackJack.dealer.cards.length; j++) {
            if (_blackJack.dealer.cards[j].value == 11) {
                if (_blackJack.dealer.cardOldSum + 11 < 21 && _blackJack.dealer.cardSum + 11 < 21) {
                    _blackJack.dealer.cardSum = _blackJack.dealer.cardSum + 11;
                }
                else {
                    _blackJack.dealer.cardSum = _blackJack.dealer.cardSum + 1;
                }
            }
            else {
                _blackJack.dealer.cardSum = _blackJack.dealer.cardSum + parseInt(_blackJack.dealer.cards[j].value);
            }
        }
        if (_blackJack.dealer.cardSum > 21) {
            _blackJack.dealer.message = "Bust";
        }
    }
    function _checkGameStatus() {
        var showDealerCard = true;
        for (var i = 0; i < _blackJack.players.length; i++) {
            if (_blackJack.players[i].stand == false && _blackJack.players[i].isPlaying == true) {
                showDealerCard = false;
                break;
            }
        }
        if (showDealerCard == true) {
            _blackJack.showDealerCard = true;
            _calculateDealerCardSum();
            while (_blackJack.dealer.cardSum < 17) {
                _blackJack.dealer.cards.push(_drawCard());
                _calculateDealerCardSum();
            }
            for (var j = 0; j < _blackJack.players.length; j++) {
                if (_blackJack.dealer.cardSum == _blackJack.players[j].cardSum && _blackJack.players[j].status != "Lost") {
                    _blackJack.players[j].message = "Draw";
                    _blackJack.players[j].status = "Draw";
                }
                else {
                    if ((_blackJack.dealer.cardSum > 21 || (_blackJack.dealer.cardSum < _blackJack.players[j].cardSum)) && _blackJack.players[j].status != "Lost") {
                        _blackJack.players[j].message = "Win";
                        _blackJack.players[j].status = "Win";
                    }
                    else {
                        _blackJack.players[j].message = "Lose";
                        _blackJack.players[j].status = "Lost";
                    }

                }
            }

        }
    }
    _blackJack.selectPlayer = function (player) {
        if (_blackJack.gameStarted == false) {
            player.isPlaying = !player.isPlaying;
        }
    }

    _blackJack.newGame = function () {
        _shuffleCards();
        _blackJack.gameStarted = true;
        _blackJack.showDealerCard = false;
        _blackJack.dealer = { name: "Dealer", cards: [], cardSum: 0, cardOldSum: 0 };
        for (var j = 0; j < 2; j++) {
            _blackJack.dealer.cards.push(_drawCard());
            for (var i = 0; i < _blackJack.players.length; i++) {
                if (_blackJack.players[i].isPlaying == true) {
                    _blackJack.players[i].cards.push(_drawCard());
                }
            }

        }
        _calculateAllPlayerCardSum();
    }
    _blackJack.hit = function (player) {
        player.cards.push(_drawCard());

        _calculatePlayerCardSum(player);
        if (player.cardSum == 21) {
            player.message = "You Have Black Jack";
            player.stand = true;
            _blackJack.playerHasBlackJack = true;
        }
        if (player.cardSum > 21) {
            player.message = "Bust";
            player.status = "Lost";
            player.stand = true;
            
        }
        _checkGameStatus();
    }
    _blackJack.stand = function (player) {
        player.stand = true;
        _checkGameStatus();
    }
    _blackJack.createNewPlayers = function () {
        _blackJack.dealer = { name: "Dealer", cards: [], cardSum: "0", cardOldSum: 0,message:"" };
        _blackJack.gameStarted = false;
        _blackJack.showDealerCard = false;
        _blackJack.players = [];
        for (var i = 1; i < 5; i++) {
            _blackJack.players.push({ name: "Player " + i, cards: [], cardSum: 0, message: "", cardOldSum: 0, status: "", stand: false });
        }
    }

    _blackJack.createNewPlayers();
    $scope.blackJack = _blackJack;
}]);