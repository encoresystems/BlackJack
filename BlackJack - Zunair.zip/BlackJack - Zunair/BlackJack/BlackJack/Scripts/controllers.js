﻿'use strict';

// Google Analytics Collection APIs Reference:
// https://developers.google.com/analytics/devguides/collection/analyticsjs/

angular.module('app.controllers', [])

    
    // Path: /help
    .controller('HelpCtrl', ['$scope', function ($scope) {
        $scope.$root.title = 'AngularJS BlackJack | Help';
       
    }])

   
