﻿blackJackApp.controller('GameController', ['$scope', function ($scope) {
    $scope.$root.title = 'AngularJS BlackJack';

    var _game = {};

    _game.dealer = {};
    _game.players = [];

    var player = {};

    _game.isStart = true;
    _game.isGame = false;
    _game.showDealerSum = false;


    _game.startGame = function () {

        _clear();
        _game.isGame = true;
        _game.isStart = false;
            
        _initDeck();
        _dealCards();

    };

    function _initDeck() {

        _game.dealer = {
            name: "Dealer",
            cards: [],
            sum: 0,
            draw: 0,
            status: ""
        };

        for (var i = 0; i < _game.numPlayers; i++) {
            _game.players.push(_getPlayer(i + 1));
        }
        
        _game.dealer.sum = 0;

        var ranks = new Array("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K");
        var suits = new Array("S", "C", "D", "H");

        var length = ranks.length * suits.length;

        for (var j = 0; j < suits.length; j++)
            for (var k = 0; k < ranks.length; k++) {
                _game.deck[j * ranks.length + k] = ranks[k] + ' ' + suits[j];
            }
        
        _shuffleDeck();
    }

    function _getPlayer(playerCount) {
        var tempPlayer = {
            name: "Player" + ' ' + playerCount,
            cards: [],
            sum: 0,
            draw: 0,
            status: "",
            isWinner: false,
            isLoser: false,
            isDraw: false,
            showButtons: true
        };

        return tempPlayer;
    }

    function _shuffleDeck() {
        var deckLength = _game.deck.length
        var rand, temp;

        for (var i = deckLength - 1; i > 0; i--) {
            rand = Math.floor(Math.random() * i);
            temp = _game.deck[i];
            _game.deck[i] = _game.deck[rand];
            _game.deck[rand] = temp;
        }
    }

    function _dealCards() {
        var card;

        for (var i = 0; i < 2; i++) {
            card = _drawCard();

            _game.dealer.cards.push(card);
            _updateDealerSum(_getCardValue(card));

            for (var j = 0; j < _game.players.length; j++) {
                card = _drawCard();
                _game.players[j].cards.push(card);
                _updatePlayerSum(j, _getCardValue(card));
            }
        }

        if (_checkBlackJack()) {
            _game.dealer.status = "BlackJack";
            _game.showDealerSum = true;

            for (var i = 0; i < _game.players.length; i++) {
                _game.players[i].showButtons = false;
            }
            _checkWin();
        }
        else {
            _game.showButtons = true;
        }

    }

    function _drawCard() {
        return _game.deck.pop();
    }

    function _updateDealerSum(value) {
        var intValue = parseInt(value);

        _game.dealer.sum = _game.dealer.sum + intValue;

        if (!_checkSum(_game.dealer.sum)) {
            _game.dealer.status = "Bust";

            for (var i = 0; i < _game.players.length; i++) {
                _game.players[i].isWinner = true;
                _game.players[i].showButtons = false;
            }
        }

    }

    function _updatePlayerSum(index, value) {
        var intValue = parseInt(value);

        for (var i = 0; i < _game.players.length; i++ ) {
            if (i == index) {
                _game.players[i].sum = _game.players[i].sum + intValue;
            }
            if (!_checkSum(_game.players[i].sum)) {
                _game.players[i].status = "Bust";
                _game.players[i].isLoser = true;
                _game.players[i].showButtons = false;
            }
        }
        
    }

    _game.hit = function (index) {
        var card = _drawCard();

        _game.players[index].cards.push(card);
        _updatePlayerSum(index, _getCardValue(card));

        _checkPlayersBust();
        
    }

    _game.stick = function (index) {

        _game.players[index].showButtons = false;

        if (_game.players[index].cards[0].indexOf("A") != -1 || _game.players[index].cards[1].indexOf("A") != -1) {
            if ((_game.players[index].sum + 10) < 21) {
                _game.players[index].sum = _game.players[index].sum + 10;
            }

            if (_game.players[index].sum == 21) {
                _game.players[index].status = "BlackJack";
                _game.players[index].isWinner = true;
                _game.players[index].showButtons = false;

            }
        }

        _checkPlayers();
        

    }

    function playDealer() {
        while (_game.dealer.sum < 17) {
            var card = _drawCard();
            _game.dealer.cards.push(card);
            _updateDealerSum(_getCardValue(card));
        }

        if (_game.dealer.sum == 21) {
            _game.dealer.status = "BlackJack";
        }
    }

    function _checkBlackJack() {
        if (_game.dealer.cards[0].indexOf("A") != -1 || _game.dealer.cards[1].indexOf("A") != -1) {
            if (_game.dealer.sum == 11) {
                _game.dealer.sum = 21;
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    function _checkSum(sum) {
        if (sum > 21) {
            return false; //Bust
        }
        return true;
    }

    function _checkWin() {
        _game.isStart = true;

        for (var i = 0; i < _game.players.length; i++) {
            if (_game.dealer.sum < _game.players[i].sum && _game.players[i].status != "Bust") {
                _game.players[i].isWinner = true;
            }
            else {
                game.players[i].isLoser = true;
            }
            if (_game.dealer.sum == _game.players[i].sum && _game.players[i].status != "Bust") {
                _game.players[i].isDraw = true;
            }
            
        }

        _game.isStart = true;
    }

    function _checkPlayers() {
        var counter = 0;

        for (var i = 0; i < _game.players.length; i++) {
            if (_game.players[i].showButtons == false) {
                counter++;
            }
        }

        if (counter == _game.players.length) {
            _game.showDealerSum = true;
            playDealer();

            _checkWin();
            _game.isStart = true;
        }
    }

    function _checkPlayersBust() {
        var counter = 0

        for (var i = 0; i < _game.players.length; i++) {
            if (_game.players[i].status == "Bust") {
                counter++;
            }
        }
        
        if (counter == _game.players.length) {
            _game.showDealerSum = true;
            _game.isStart = true;
        }
    }

    function _getCardValue(card) {

        var val = card.charAt(0);

        if (val == 'K' || val == 'Q' || val == 'J')
        {
            var a = 2;
        }

        if (card.length == 4) {
            var val1 = card.charAt(1);
            val = val + val1;
        }

        if (val == "A") {
            val = 1;
        }
        else if (val == "J" || val == "Q" || val == "K") {
            val = 10
        }

        return val;
    }

    function _clear() {
        _game.deck = [];
        _game.dealer = {};
        _game.players = [];
        player = {};
        _game.isGame = false;
        _game.showDealerSum = false;
        _game.isStart = true;
    }

    $scope.game = _game;

}]);