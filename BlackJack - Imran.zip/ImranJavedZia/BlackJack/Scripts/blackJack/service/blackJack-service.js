﻿blackJackApp.factory('blackJackService', ['$http', function ($http) {

    var _blackJackObject = {};

    //#region functions

    //get complate card deck
    _setInstance = function (callBack) {
        $http.get('cardDeck.json').
            success(function (data, status, headers, config) {
                _blackJackObject.cardDeck = data;
                _shuffleCards(_blackJackObject.cardDeck);

                if (typeof (callBack) == "function") {
                    callBack(_blackJackObject);
                }
            }).
          error(function (data, status, headers, config) {
              alert("Error in black Jack service");
          });

        return _blackJackObject;
    };

    // get service object instance
    _getInstance = function () {
        return _blackJackObject;
    };

    // initilaizes the players
    _getPlayers = function (playerCount) {
        var players = [];

        if (playerCount && playerCount >= 2) {
            var player;

            for (var i = 0; i < playerCount; i++) {
                player = {
                    playerName: i == 0 ? 'Dealer' : 'Player ' + i,
                    isDealer: i == 0,
                    isDealerActive: false,
                    cards: [],
                    score: 0,
                    status: '',
                    isStick: false
                };

                players.push(player);
            }
        }

        return players;
    }

    // dealts card to all players
    _dealtCards = function (players, cardDeck) {
        if (players && players.length >= 2) {
            var card;
            for (var round = 1; round <= 2; round++) {
                for (var i = 0; i < players.length; i++) {
                    card = cardDeck.shift();
                    players[i].cards.push(card);
                    if (round == 1 && players[i].isDealer) {
                        card.showCard = false;
                    } else {
                        card.showCard = true;
                    }
                    if (round == 2) {
                        _calculateScore(players[i], 1);
                    }
                }
            }
        }

        return players;
    }

    // hit fetch new card from deck and addes to player
    _hit = function (player, cardDeck) {
        if (player && cardDeck && cardDeck.length > 0) {
            var card = cardDeck.shift();

            card.showCard = true;
            player.cards.push(card);

            _calculateScore(player, 1);

            _checkStatus(player);
        }

        return player;
    }

    // Calculates applicable score
    _calculateScore = function (player, iteration) {
        if (player && player.cards.length > 0) {
            var secondaryUsed = 0;
            player.score = 0;

            for (var i = 0; i < player.cards.length; i++) {
                // if it is first calculation iteration or applicable sendondary value 11 or 1 for Ace then use actual value
                if (iteration == 1 || secondaryUsed >= iteration - 1) {
                    player.score += Number(player.cards[i].value);
                }
                else {
                    player.score += Number(player.cards[i].secondaryValue);
                    // if value and secondary value are different then make secondary value used, so it may use actual value 
                    if (player.cards[i].value != player.cards[i].secondaryValue) {
                        secondaryUsed++;
                    }
                }
            }

            // as there can be 4 aces, so we may never need more than 4 level checking for value 1 or 11
            if (player.score > 21 && iteration <= 4) {
                _calculateScore(player, iteration + 1)
            }
        }

        return player;
    }

    // check and update status of a single player
    _checkStatus = function (player) {
        if (player.score == 21) {
            player.isStick = true;
            player.status = 'You win!';
        }

        if (player.score > 21) {
            player.isStick = true;
            player.status = 'You lost :('
        }
    }

    // check and update final status for all players w.r.t dealer
    _checkFinalStatus = function (dealer, players) {
        var stickedPlayers = _getStickedPlayer(players);
        var player;
        for (var i = 0; i < stickedPlayers.length; i++) {
            player = stickedPlayers[i];

            if (player.score > 21) {
                player.status = 'You lost :('
            }
            else if (dealer.score > 21) {
                player.status = 'You win!';
            } else if (player.score > dealer.score) {
                player.status = 'You win!';
            } else if (player.score < dealer.score) {
                player.status = 'You lost :(';
            } else if (player.score == dealer.score) {
                player.status = 'Draw :~|';
            }
        }
    }

    // Sheffes cards
    _shuffleCards = function (cardDeck) {
        if (cardDeck) {
            var totalCards = cardDeck.length;
            var totalShuffles = 26;
            var firstCardIndex, secondCardIndex, temp;

            for (var i = 0; i <= totalShuffles; i++) {
                firstCardIndex = Math.floor(Math.random() * (totalCards));
                secondCardIndex = Math.floor(Math.random() * (totalCards));
                temp = cardDeck[firstCardIndex];
                cardDeck[firstCardIndex] = cardDeck[secondCardIndex];
                cardDeck[secondCardIndex] = temp;
            }
        }
        else {
            cardDeck = [];
        }

    }

    // Execute Dealer
    _activateDealer = function (players) {
        var dealer = _getDealer(players);

        var stickedPlayers = _getStickedPlayer(players);

        if (stickedPlayers.length == players.length - 1) {
            dealer.isDealerActive = true;
            dealer.cards[0].showCard = true;
        }
    }

    // get dealer
    _getDealer = function (players) {
        return _.first(players);
    }

    // returns player how have sticked
    _getStickedPlayer = function (players) {
        var stickedPlayers = _.filter(players, function (item) {
            if (item.isDealer == false && item.isStick == true) {
                return item;
            }
        });

        return stickedPlayers;
    }

    // returns all players except dealer
    _getNonDealer = function (players) {
        var stickedPlayers = _.filter(players, function (item) {
            if (item.isDealer == false) {
                return item;
            }
        });

        return stickedPlayers;
    }

    // test black jack
    _checkDealer = function (players, isBlackJackCheck) {
        var continueProcess = false;
        var dealer = _getDealer(players);
        if (isBlackJackCheck) {
            if (dealer.score == 21) {
                _checkStatus(dealer);
                var nonDealer = _getNonDealer(players);
                for (var i = 0; i < nonDealer.length; i++) {
                    nonDealer[i].isStick = true;
                }
                _checkStatus(dealer);
                _activateDealer(players);
            }
            else {
                continueProcess = true;
            }
        }
        else {
            var stickedPlayer = _getStickedPlayer(players);
            for (var i = 0; i < stickedPlayer.length; i++) {
                if (stickedPlayer[i].score < 21 && stickedPlayer[i].score > dealer.score) {
                    continueProcess = true;
                    break;
                }
            }
        }
        return continueProcess;
    }

    //#endregion

    return {
        setInstance: _setInstance,
        getInstance: _getInstance,
        getPlayers: _getPlayers,
        shuffleCards: _shuffleCards,
        dealtCards: _dealtCards,
        hit: _hit,
        getDealer: _getDealer,
        getStickedPlayer: _getStickedPlayer,
        getNonDealer: _getNonDealer,
        activateDealer: _activateDealer,
        checkStatus: _checkStatus,
        checkDealer: _checkDealer,
        checkFinalStatus: _checkFinalStatus
    };
}]);