﻿blackJackApp.controller('blackJackController', ['$scope', 'blackJackService', function ($scope, blackJackService) {
    var _blackJack = {};
    _blackJack.playerCount =3;
    
    //#region functions

    //Start Game
    _blackJack.startGame = function (isValid, playerCount) {
        if (isValid) {
            blackJackService.setInstance(function (reponse) {
                _blackJack.cardDeck = reponse.cardDeck;

                _blackJack.players = blackJackService.getPlayers(playerCount, _blackJack.cardDeck);

                blackJackService.dealtCards(_blackJack.players, _blackJack.cardDeck);

                blackJackService.checkDealer(_blackJack.players, true);
            });
        }
    };

    //Player click Hit
    _blackJack.hit = function (player) {
        blackJackService.hit(player, _blackJack.cardDeck);

        _blackJack.activateDealer(player);
    };

    //Player click Stick
    _blackJack.stick = function (player) {
        player.isStick = true;

        _blackJack.activateDealer(player);
    };

    // activate dealer if required
    _blackJack.activateDealer = function (player) {
        if (player.isDealer == false) {

            blackJackService.activateDealer(_blackJack.players);

            var dealer = blackJackService.getDealer(_blackJack.players);


            if (dealer.isDealerActive == true) {
                _blackJack.executeDealer(_blackJack.players);
            }
        }


    }

    // automates dealer flow
    _blackJack.executeDealer = function (players) {
        var dealer = blackJackService.getDealer(players);
        while(blackJackService.checkDealer(players, false)==true && dealer.isStick==false){
            _blackJack.hit(dealer);
        }
        blackJackService.checkFinalStatus(dealer, players);
    }


    //#endregion

    $scope.blackJack = _blackJack;

}]);